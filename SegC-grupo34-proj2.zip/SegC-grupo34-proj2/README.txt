
Projeto 2 em trabalho, vai sendo atualizado.

Diogo Pinto 52763 
Francisco Ramalho 53472
Joao Funenga 53504

----------------

** COMANDOS DE COMPILACAO **

- Comando para compilar as classes relativas ao servidor:
javac -d bin src/Server/SeiTchizServer.java src/Server/CatalogoClientes.java src/Server/CatalogoGrupos.java src/Server/Cliente.java src/Server/Grupo.java src/Server/Mensagem.java src/Server/Photo.java


- Comando para compilar a classe relativa ao cliente:
javac -d bin src/Client/SeiTchiz.java

----------------

** COMANDOS DE EXECUCAO **

Ter em atencao, que para ser possivel o uso da aplicacao, e necessario iniciar o servidor primeiro que os clientes.

- Exemplo de comando para execucao do servidor:
Executar ficheiros .class:
java -cp bin -Djava.security.manager -Djava.security.policy==server.policy Server.SeiTchizServer 45678
java -cp bin -Djava.security.manager -Djava.security.policy==server.policy Server.SeiTchizServer 45678 keystore keystore-password

Executar ficheiro .jar:
java -cp bin -Djava.security.manager -Djava.security.policy==server.policy -jar SeiTchizServer.jar 45678


- Exemplo de comando para execucao do cliente:
Executar ficheiros .class:
java -cp bin -Djava.security.manager -Djava.security.policy==client.policy Client.SeiTchiz 127.0.0.1:45678 userName password123
java -cp bin -Djava.security.manager -Djava.security.policy==client.policy Client.SeiTchiz 127.0.0.1:45678 truststore keystore keystore-password clientid

Executar ficheiro .jar:
java -cp bin -Djava.security.manager -Djava.security.policy==client.policy -jar SeiTchiz.jar 127.0.0.1:45678 userName password123

----------------

Argumentos usados para servidor:
45678 - porto exemplo

Argumentos usados para cliente:
127.0.0.1:45678 - serverAddress
userName - userID
password123 - password

----------------

Limitacoes: 
As fotografias usadas para o comando Post devem estar dentro da pasta "test" na raiz do projeto (devido a permissoes dos policies).
A mensagem enviada para os grupos nao deve conter "%%" (é uma palavra reservada para tratamento de ficheiros).
A pasta bin não pode ser apagada, apenas devem ser apagados os seus conteúdos.

-----------------

Observações
As pastas wall e data (incluindo as subpastas) podem ser apagadas antes de correr o código. Caso existam ao iniciar o programa, serão carregados os
dados existentes. Caso estas pastas tenham sido apagadas, são geradas automaticamente e a informação acerca dos clientes será "apagada".
O codigo foi testado na imagem de linux do DI e no Windows 10. 

----------------
Gerar chave privada e publica

keytool -genkeypair -alias servidor -keyalg RSA -keysize 2048 -storetype JCEKS -keystore servidor

